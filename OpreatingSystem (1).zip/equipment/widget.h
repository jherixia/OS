#ifndef WIDGET_H
#define WIDGET_H
#include <time.h>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QTableWidget>
#include <QAbstractTableModel>
#include "ui_dequip.h"
#include <QQueue>
#include "dequip.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    int totalPrint;
    int totalKeyboard;
    int totalMouse;
    int totalBluetooth;
    int rePrint;    //剩余
    int reKey;
    int reMouse;
    int reBlue;
    struct Process{
        int pId;
        int print;
        int keyboard;
        int mouse;
        int bluetooth;
        int getPrint;
        int getKey;
        int getMouse;
        int getBluetooth;
    };
    Process proc[16];
    QQueue <Process> wait;
    ~Widget();

private slots:
    void on_createPro_clicked();
    void on_closeButton_clicked();


    void on_StartButton_clicked();

    void waitAppendSlot (int pId);

private:
    Ui::Widget *ui;

};

#endif // WIDGET_H
