#include "widget.h"
#include "ui_widget.h"
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    srand((unsigned)time(NULL));
    ui->setupUi(this);
    totalBluetooth = 36;
    totalKeyboard = 36;
    totalMouse = 36;
    totalPrint = 36;
    reBlue = 36;
    reKey = 36;
    reMouse =36;
    rePrint = 36;
    for (int i = 0; i < 16; i++){
        proc[i].getBluetooth = 0;
        proc[i].getKey = 0;
        proc[i].getMouse = 0;
        proc[i].getPrint = 0;
    }

}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_createPro_clicked()
{
    for (int i = 0; i < 16; i++){
        proc[i].pId = i;
        proc[i].bluetooth = rand() % 12;
        proc[i].getBluetooth = rand() %4;
        while (proc[i].getBluetooth > proc[i].bluetooth){
            proc[i].getBluetooth = rand() % 4;
        }
        proc[i].keyboard = rand() % 12;
        proc[i].getKey = rand() % 4;
        while (proc[i].getKey > proc[i].keyboard){
            proc[i].getKey = rand() % 4;
        }
        proc[i].mouse = rand() % 12;
        proc[i].getMouse = rand() % 4;
        while (proc[i].getMouse > proc[i].mouse){
            proc[i].getMouse = rand() % 4;
        }
        proc[i].print = rand() % 12;
        proc[i].getPrint = rand() % 4;
        while (proc[i].getPrint > proc[i].print){
            proc[i].getPrint = rand() % 4;
        }
        //qDebug() << proc[i].bluetooth;
    }
    QMessageBox::information(this, "提示", "生成成功！");
}

void Widget::on_closeButton_clicked()
{
    Widget::close();
}

void Widget::waitAppendSlot(int pId){
    wait.enqueue(proc[pId]);
}

void Widget::on_StartButton_clicked()
{
    Dequip *dist = new Dequip;
    dist->show();
    for (int i = 0; i < 16; i++){
        dist->ui->tableWidget->setItem(i,0,new QTableWidgetItem("p"+QString::number(proc[i].pId)));
        dist->ui->tableWidget->setItem(i,1,new QTableWidgetItem(QString::number(proc[i].bluetooth)));
        dist->ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::number(proc[i].keyboard)));
        dist->ui->tableWidget->setItem(i,3,new QTableWidgetItem(QString::number(proc[i].mouse)));
        dist->ui->tableWidget->setItem(i,4,new QTableWidgetItem(QString::number(proc[i].print)));
        dist->ui->tableWidget->setItem(i,5,new QTableWidgetItem(QString::number(proc[i].getBluetooth)));
        dist->ui->tableWidget->setItem(i,6,new QTableWidgetItem(QString::number(proc[i].getKey)));
        dist->ui->tableWidget->setItem(i,7,new QTableWidgetItem(QString::number(proc[i].getMouse)));
        dist->ui->tableWidget->setItem(i,8,new QTableWidgetItem(QString::number(proc[i].getPrint)));
        dist->ui->tableWidget->setItem(i,9,new QTableWidgetItem(QString::number(proc[i].bluetooth-proc[i].getBluetooth)));
        dist->ui->tableWidget->setItem(i,10,new QTableWidgetItem(QString::number(proc[i].keyboard-proc[i].getKey)));
        dist->ui->tableWidget->setItem(i,11,new QTableWidgetItem(QString::number(proc[i].mouse-proc[i].getMouse)));
        dist->ui->tableWidget->setItem(i,12,new QTableWidgetItem(QString::number(proc[i].print-proc[i].getPrint)));
        int useBlue = 0;
        int useKey = 0;
        int useMouse = 0;
        int usePrint = 0;
        for (int i = 0; i < 16; i++){
            useBlue += proc[i].getBluetooth;
            useKey += proc[i].getKey;
            useMouse += proc[i].getMouse;
            usePrint += proc[i].getPrint;
        }
        reBlue = totalBluetooth - useBlue;
        reKey = totalKeyboard - useKey;
        reMouse = totalMouse - useMouse;
        rePrint = totalPrint - usePrint;
    }
    dist->ui->remain->setItem(0,0,new QTableWidgetItem(QString::number(reBlue)));
    dist->ui->remain->setItem(0,1,new QTableWidgetItem(QString::number(reKey)));
    dist->ui->remain->setItem(0,2,new QTableWidgetItem(QString::number(reMouse)));
    dist->ui->remain->setItem(0,3,new QTableWidgetItem(QString::number(rePrint)));
    connect(dist, &Dequip::sendWaitToWidget, this, &Widget::waitAppendSlot);

}
