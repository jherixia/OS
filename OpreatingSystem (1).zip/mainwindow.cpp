#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setFixedSize(1520,920);
    setWindowTitle("模拟操作系统");
    processTab=new ProcessTab(this);
    memoryTab=new Memory(this);
    fileTab = new File(this);
    equipmentTab = new Widget(this);
    diskTab = new Disk(this);
    mywidget = new MyWidget(this);

    fileTab->disk=diskTab;

    ui->processArea->setWidget(processTab);
    ui->memoryArea->setWidget(memoryTab);
    ui->diskArea->setWidget(diskTab);
    ui->tabWidget->clear();
    ui->tabWidget->addTab(fileTab,"文件管理");
    ui->tabWidget->addTab(equipmentTab,"死锁演示");
    ui->tabWidget->addTab(mywidget,"线程机制");
}

MainWindow::~MainWindow()
{
    delete ui;
}
