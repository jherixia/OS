#include "timeThread.h"

timeThread::timeThread(QObject *parent) : QThread(parent)
{

}

void timeThread::run()
{
    while(1)
    {
        emit timeSignal();
        QThread::sleep(1);
    }
}

