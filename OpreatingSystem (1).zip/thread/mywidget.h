#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>
#include<QTime>
#include<QDateTime>
#include"randThread.h"
#include"timeThread.h"
QT_BEGIN_NAMESPACE
namespace Ui {
class MyWidget;
}
QT_END_NAMESPACE


class MyWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MyWidget(QWidget *parent = nullptr);
    ~MyWidget();

public slots:
    void timeSlot();
    void randSlot();
    //线程结束函数
    void quitThreadSlot();

private slots:
    void on_pushButton_open_clicked();

    void on_pushButton_close_clicked();

private:
    Ui::MyWidget *ui;
    //...线程对象....
    randThread*pRandThread;
    timeThread*pTimeThread;
};

#endif // MYWIDGET_H
