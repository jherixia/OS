#include "mywidget.h"
#include "ui_mywidget.h"

MyWidget::MyWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyWidget)
{
    ui->setupUi(this);
    setWindowTitle("qt的多线程");
    //....创建线程对象.......
    pRandThread=new randThread(this);
    pTimeThread=new timeThread(this);
    //...调用run函数...每隔1s发送一个信号...
    pRandThread->start();
    pTimeThread->start();

    ui->pushButton_open->setEnabled(false);


    connect(pTimeThread,SIGNAL(timeSignal()),this,SLOT(timeSlot()));
    connect(pRandThread,SIGNAL(randSignal()),this,SLOT(randSlot()));
    //关闭窗口的时候结束线程
    connect(this,SIGNAL(destroyed()),this,SLOT(quitThreadSlot()));

}


MyWidget::~MyWidget()
{
    delete ui;
}

void MyWidget::timeSlot()
{
    //.1.获取当前的时间
    QDateTime currentTime=QDateTime::currentDateTime();
    QString str_time=currentTime.toString("yyyy.MM.dd ddd hh:mm:ss");
    ui->lineEdit_time->setText(str_time);

}

void MyWidget::randSlot()
{
    // 1.获取一个随机数
    QString str_rand=QString("%1").arg(rand()%30);
    // 2.显示到文本
    ui->lineEdit_rand->setText(str_rand);
}

void MyWidget::quitThreadSlot()
{
    pTimeThread->quit();
    pTimeThread->wait();

    pRandThread->quit();
    pRandThread->wait();
}

void MyWidget::on_pushButton_open_clicked()
{
    ui->pushButton_open->setEnabled(false);
    ui->pushButton_close->setEnabled(true);
    pRandThread->start();
}


void MyWidget::on_pushButton_close_clicked()
{
    ui->pushButton_close->setEnabled(false);
    ui->pushButton_open->setEnabled(true);
    pRandThread->terminate();
}

