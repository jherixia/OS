#ifndef TIMETHREAD_H
#define TIMETHREAD_H

#include <QObject>
#include<QThread>

class timeThread : public QThread
{
    Q_OBJECT
public:
    explicit timeThread(QObject *parent = nullptr);

signals:
    void timeSignal();//自定义信号
protected:
    void run() ; //线程入口函数

};

#endif // TIMETHREAD_H

